---
layout: docs
title: Toolbars
description: Toolbar actions appear above the view affected by their actions.
group: material
---

**Most of the details about Material toolbars have been covered in Components/Navbar documentation. Please refer to [this page]({{ site.baseurl }}/docs/{{ site.docs_version }}/components/navbar/) for more details.**
